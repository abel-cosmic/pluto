Write a Python script that reads `/app/data/transactions.json` and writes the result to `/app/data/reconciled_ledger.json`

Each output record needs exactly these fields

- id (string)
- user_id (string)
- name (string)
- email (string)
- amount_usd (float, 2 decimal places)
- fee_usd (float, 2 decimal places)
- type (string)
- status (string)
- timestamp (string, YYYY-MM-DD HH:MM:SS)
- row_hash (string)

**Deduplication**

Drop exact duplicate records. Also drop near-duplicate double charges where the same user_id has the same type and amount with timestamps within 3 seconds of each other — keep the first one only

**Name cleanup**

Strip whitespace. Flip "Last First" names to "First Last". Remove quoted nicknames like "Bill". Drop middle initials like A. Remove title prefixes: Dr Mr Mrs Ms Prof Sir Mme MD PhD Ph.D Jr Sr III IV. Normalize unicode diacritics to ASCII so é becomes e and ü becomes u. Replace ligatures: æ becomes ae, œ becomes oe, ß becomes ss. Apply title case but keep particles lowercase: de di van von der du

**Email**

Replace [at] (at) _at_ with @ and [dot] (dot) _dot_ with a period. A valid email ends with @company.com and has exactly one @. If the email is invalid or missing generate one as firstinitial.lastname@company.com in lowercase. For collisions the first person keeps the base form like j.smith@company.com and each next one gets a number appended so j.smith2@company.com then j.smith3@company.com

**Currency to USD**

Fixed rates: USD 1.00 / EUR 1.10 / GBP 1.25 / BTC 60000.00 / ETH 3000.00

k or K suffix means multiply by 1000. Currency code starting with K like kUSD applies the multiplier then the rate. If the amount cant be parsed set amount_usd to null

**Fee imputation**

When fee_usd is null fill it in using this order

1. if the dept x year group has 3 or more known fees use that groups median
2. otherwise use 0.5 times group median plus 0.3 times year median plus 0.2 times dept median treating missing subgroups as 0
3. if no dept or year data exists use the global median
4. if the global median is also 0 use 7.30

Round to 2 decimal places

**Refunds**

A refund needs a parent_id that points to a real non-refund transaction otherwise drop it. If refund amount_usd is >= parent amount_usd set parent status to refunded otherwise set it to partially_refunded. Set the refund record status to settled

**Timestamps**

Parse in this order

1. N days ago means subtract N days from 2026-05-20 12:00:00
2. starts with 0x means hex unix timestamp
3. number between 10000 and 99999 is an Excel serial date with base 1899-12-30
4. number above 100000000 is a unix timestamp
5. ISO 8601 string — convert to UTC and strip timezone

If the timestamp cant be parsed or is missing use the median timestamp of other records in the same department. If theres no department data use the company wide median. Format all timestamps as YYYY-MM-DD HH:MM:SS

**Drop records where**

- amount_usd is null or below 5.00 or above 1000000.00
- timestamp is before 2020-01-01 00:00:00
- user_id has characters other than letters digits hyphens and underscores

**Sort** by timestamp ascending then by id ascending

**Row hash**

SHA-256 of this pipe delimited string

{id}|{user_id}|{amount_usd:.2f}|{fee_usd:.2f}|{type}|{status}|{timestamp}

Store the hex digest in row_hash

**Output**

Write to `/app/data/reconciled_ledger.json` with 2 space indentation
